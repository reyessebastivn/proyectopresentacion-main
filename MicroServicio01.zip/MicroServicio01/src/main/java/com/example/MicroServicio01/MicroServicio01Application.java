package com.example.MicroServicio01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServicio01Application {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicio01Application.class, args);
	}

}
